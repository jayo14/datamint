# DataMint Mobile App — entire project

This project’s pages, files, and uploads as this browser tab had them at export.
Anything left out is listed below.

## Contents

- `Main.dc.html`
- `app.css`
- `auth-1-welcome.dc.html`
- `auth-2-phone.dc.html`
- `auth-3-otp.dc.html`
- `auth-4-wallet.dc.html`
- `auth-5-profile.dc.html`
- `auth-6-permissions.dc.html`
- `auth-7-success.dc.html`
- `canvas.json` — the canvas: its pages, where each artboard sits, its notes and shapes
- `components.dc.html`
- `flow-map.dc.html`
- `history.dc.html`
- `home.dc.html`
- `notifications.dc.html`
- `offline.dc.html`
- `onboarding-1.dc.html`
- `onboarding-2.dc.html`
- `onboarding-3.dc.html`
- `photo-1-capture.dc.html`
- `photo-2-review.dc.html`
- `profile.dc.html`
- `receipt.dc.html`
- `settings.dc.html`
- `task-detail.dc.html`
- `task-paid.dc.html`
- `task-rejected.dc.html`
- `tasks-empty.dc.html`
- `tasks-filters.dc.html`
- `tasks.dc.html`
- `text-task.dc.html`
- `validating.dc.html`
- `voice-1-ready.dc.html`
- `voice-2-recording.dc.html`
- `voice-3-review.dc.html`
- `wallet.dc.html`
- `withdraw-1-amount.dc.html`
- `withdraw-2-review.dc.html`
- `withdraw-3-sent.dc.html`
- `_runtime/` — what runs the pages in a browser; not part of the design

## Viewing

To view a page, start a local web server in this folder (for example `python3 -m http.server`), then open an artboard’s `.dc.html` file through it. Opening the file directly may not work, because some browsers block its scripts.

## Left out of this export

The export never includes hidden files (files whose names start with a dot) or
files the editor keeps for its own use.
